﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Testeajax.Models
{
    public class RepeaterTemperatura
    {
        public DateTime datahora { get; set; }
        public double valor { get; set; }

    }
}